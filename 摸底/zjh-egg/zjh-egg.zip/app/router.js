"use strict";

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  router.post("/user/login", controller.user.login);

  router.post("/fabiao", controller.home.fabiao);
  router.post("/liebiao", controller.home.liebiao);
};
