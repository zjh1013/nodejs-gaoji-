const { Controller } = require("egg");

class HomeController extends Controller {
  async fabiao() {
    const { ctx } = this;
    const { title, content } = ctx.request.body;
    const $sql = `insert into liebiao (title,content)values(?,?)`;
    const $params = [title, content];
    const result = await this.app.mysql.query($sql, $params);
    if (result.affectedRows > 0) {
      ctx.body = {
        code: 1,
        result
      };
      ctx.body = {
        code: 0
      };
    }
  }

  async liebiao() {
    const { ctx } = this;
    // const { title, content } = ctx.request.body;
    const $sql = `select * from liebiao`;
    // const $params = [title, content];
    const result = await this.app.mysql.query($sql);
    ctx.body = {
      code: 1,
      result
    };
    // if (result) {
    //   ctx.body = {
    //     code: 1,
    //     result
    //   };
    //   ctx.body = {
    //     code: 0
    //   };
    // }
  }
}
module.exports = HomeController;
