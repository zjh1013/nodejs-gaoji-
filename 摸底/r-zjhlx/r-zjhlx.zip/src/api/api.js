// import instance from "../request/request";

// export const login = ({ username, password }) => {
//   const url = "/user/login";
//   return instance.post(url, { username, password });
// };

// export const fabiao = ({ title, content }) => {
//   const url = "/fabiao";
//   return instance.post(url, { title, content });
// };
