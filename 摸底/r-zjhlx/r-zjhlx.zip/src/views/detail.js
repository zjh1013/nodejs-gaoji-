import React, { Component } from "react";

export default class detail extends Component {
  state = {
    aa: ""
  };
  render() {
    const { query } = this.props.location;

    return (
      <div>
        <div>
          <h1>{query.title}</h1>
          <p>{query.content}</p>
        </div>
        <p>已有0人评论</p>

        <div>
          <input onChange={this.changeaa} />
          <button></button>
        </div>
      </div>
    );
  }
  changeaa = e => {
    this.setState({
      aa: e.target.value
    });
    console.log(this.state.aa);
  };
}
