import React, { Component } from "react";
import Hea from "../components/header";
import axios from "axios";
export default class liebiao extends Component {
  state = {
    liebiao: []
  };
  render() {
    const { liebiao } = this.state;
    return (
      <div>
        <div className="shang">
          <div>
            {liebiao.map((item, index) => (
              <div
                key={index}
                className="aa"
                onClick={this.xq.bind(this, item.id, item)}
              >
                <h2>{item.title}</h2>
              </div>
            ))}
          </div>
        </div>
        <Hea></Hea>
      </div>
    );
  }
  xq(id, item) {
    let { history } = this.props;
    history.push({
      pathname: "/detail",
      query: item
    });
  }
  componentDidMount() {
    axios.post("/liebiao").then(res => {
      this.setState({
        liebiao: res.data.result
      });
    });
  }
}
